import { Component } from '@angular/core';

@Component({
  selector: 'ngx-bootstrap',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class BootstrapComponent {
}
